async function checkURL() {
  const url = document.getElementById("urlInput").value;

  if (!url) {
    alert("Please enter a URL");
    return;
  }

  const response = await fetch("http://localhost:5001/check", {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({ url })
  });

  const data = await response.json();

  let colorClass = "safe";
  if (data.score >= 5) colorClass = "danger";
  else if (data.score >= 3) colorClass = "warning";

  document.getElementById("result").innerHTML = `
    <h3 class="${colorClass}">${data.result}</h3>
    <p><strong>Risk Score:</strong> ${data.score}</p>
    <p><strong>Reasons:</strong></p>
    <ul>
      ${data.reasons.map(r => `<li>${r}</li>`).join("")}
    </ul>
  `;
}