# 🛡️ Phishing Detection & Awareness System

## 📌 Project Overview
This project is a web-based cybersecurity application designed to detect phishing websites and raise awareness among users. It analyzes URLs using a rule-based scoring algorithm to classify them as Safe, Suspicious, or Phishing.

---

## 🎯 Objective
The main objective of this project is to help users identify malicious websites and prevent cyber attacks such as data theft, account hacking, and financial fraud.

---

## ⚙️ How It Works
The system evaluates a given URL based on multiple security parameters:
- HTTPS availability
- URL length
- Presence of suspicious characters (@, -)
- Detection of sensitive keywords (login, bank, verify, etc.)
- IP address usage instead of domain

Each factor contributes to a risk score, and based on the total score, the system classifies the URL.

---

## 🔍 Features
- URL Analysis System
- Risk Score Calculation
- Phishing Detection (Safe / Suspicious / Phishing)
- Awareness Section for Cyber Safety
- Simple and User-Friendly Interface

---

## 🛠️ Technology Stack
- Frontend: HTML, CSS, JavaScript
- Backend: Node.js, Express.js
- API Communication using Fetch

---

## 🚀 How to Run the Project

### 1. Clone the repository
git clone https://github.com/your-username/phishing-detector.git

### 2. Navigate to backend folder
cd backend

### 3. Install dependencies
npm install

### 4. Start the server
node server.js

### 5. Run frontend
Open frontend/index.html in your browser

---

## 📊 Output Example
- ✅ Safe Website
- ⚠️ Suspicious Website
- ❌ Phishing Website

---

## 📸 Screenshots
(Add your project screenshots here)

---

## 🔗 GitHub Repository
(Add your repository link here)

---

## 🔮 Future Scope
- Integration with AI/ML models for better accuracy
- Real-time phishing database API integration
- Browser extension development
- Mobile application version

---

## 👨‍💻 Author
Rahul