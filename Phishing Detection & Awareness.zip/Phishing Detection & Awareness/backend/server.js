const express = require("express");
const cors = require("cors");

const app = express();
app.use(cors());
app.use(express.json());

function checkPhishing(url) {
  let score = 0;
  let reasons = [];

  if (!url.startsWith("https://")) {
    score += 2;
    reasons.push("No HTTPS (Not Secure)");
  }

  if (url.length > 75) {
    score += 1;
    reasons.push("URL is too long");
  }

  if (url.includes("@") || url.includes("-")) {
    score += 2;
    reasons.push("Suspicious symbols detected");
  }

  const suspiciousWords = ["login", "verify", "bank", "secure", "update"];
  suspiciousWords.forEach(word => {
    if (url.toLowerCase().includes(word)) {
      score += 1;
      reasons.push(`Contains suspicious word: ${word}`);
    }
  });

  const ipPattern = /(\d{1,3}\.){3}\d{1,3}/;
  if (ipPattern.test(url)) {
    score += 3;
    reasons.push("Uses IP address instead of domain");
  }

  let result = "";
  if (score >= 5) result = "❌ Phishing Website";
  else if (score >= 3) result = "⚠️ Suspicious Website";
  else result = "✅ Safe Website";

  return { result, score, reasons };
}

app.post("/check", (req, res) => {
  const { url } = req.body;
  const analysis = checkPhishing(url);
  res.json(analysis);
});

app.listen(5001, () => {
  console.log("Server running on http://localhost:5000");
});